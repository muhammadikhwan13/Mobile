package com.sneakers

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class DashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        // Mengambil referensi ke tombol-tombol menu
        val buttonMenu1 = findViewById<Button>(R.id.btnshoecollection)
        buttonMenu1.setOnClickListener { Intent(this,ShoeCollectionActivity::class.java)
            startActivity(intent)}

        // Menetapkan fungsi klik untuk masing-masing tombol menu
        buttonMenu1.setOnClickListener {
            // Ganti dengan tindakan yang sesuai, misalnya:
            // Memulai aktivitas untuk menampilkan koleksi sepatu
            startActivity(Intent(this, ShoeCollectionActivity::class.java))
        }

    }
}

