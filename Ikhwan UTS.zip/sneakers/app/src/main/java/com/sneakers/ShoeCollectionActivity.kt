package com.sneakers

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ShoeCollectionActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_collection)

        // Mengambil referensi ke ListView dari layout
        val listView: ListView = findViewById(R.id.listViewcollection)

        // Isi data koleksi sepatu
        val koleksiSepatu = listOf("Adidas", "Nike", "Converse", "Vans", "Puma", "New Balance", "Reebok", "Asics", "Diadora", "Under Armour")

        // Membuat adapter untuk ListView
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, koleksiSepatu)

        // Mengatur adapter ke ListView
        listView.adapter = adapter

        // Menambahkan event listener untuk ListView
        listView.setOnItemClickListener { parent, view, position, id ->
            // Ambil item yang dipilih dari ListView
            val selectedItem = parent.getItemAtPosition(position) as String
            // Tampilkan gambar sesuai dengan item yang dipilih
            when (selectedItem) {
                "Adidas" -> showImage(R.drawable.adidas)
                "Nike" -> showImage(R.drawable.nike)
                "Converse" -> showImage(R.drawable.converse)
                "Vans" -> showImage(R.drawable.vans)
                "Puma" -> showImage(R.drawable.puma)
                "New Balance" -> showImage(R.drawable.nb)
                "Reebok" -> showImage(R.drawable.reebok)
                "Asics" -> showImage(R.drawable.asics)
                "Diadora" -> showImage(R.drawable.diadora)
                "Under Armour" -> showImage(R.drawable.ua)
            }
            val textView: TextView = findViewById(R.id.textView)
            when (selectedItem) {
                "Adidas" -> textView.text = "Brand: Adidas\nModel: Ultraboost\nSize: 42\nColor: Black/White"
                "Nike" -> textView.text = "Brand: Nike\nModel: Air Max\nSize: 40\nColor: black/White"
                "Converse" -> textView.text = "Brand: Converse\nModel: Chuck Taylor\nSize: 38\nColor: black/white"
                "Vans" -> textView.text = "Brand: Vans\nModel: Old Skool\nSize: 39\nColor: Black/White"
                "Puma" -> textView.text = "Brand: Puma\nModel: Suede\nSize: 41\nColor: Green/White"
                "New Balance" -> textView.text = "Brand: New Balance\nModel: 574\nSize: 40\nColor: Grey"
                "Reebok" -> textView.text = "Brand: Reebok\nModel: Classic Leather\nSize: 43\nColor: White/Gum"
                "Asics" -> textView.text = "Brand: Asics\nModel: Gel-Lyte III\nSize: 41\nColor: mix"
                "Diadora" -> textView.text = "Brand: Diadora\nModel: N9000\nSize: 42\nColor: mix"
                "Under Armour" -> textView.text = "Brand: Under Armour\nModel: HOVR Phantom\nSize: 42\nColor: Black/white"
            }
        }
    }

    // Fungsi untuk menampilkan gambar pada ImageView
    private fun showImage(imageResId: Int) {
        val imageView: ImageView = findViewById(R.id.imageView) // Ubah menjadi ID ImageView Anda
        imageView.setImageResource(imageResId)
    }
}


